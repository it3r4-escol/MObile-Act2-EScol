 import 'dart:io';

bool checkFib(List<int> list) {
  for (int m = 2; m < list.length; m++) {
    if ((list[m - 1] + list[m - 2]) != list[m]) {
      return false;
    }
  }
  return true;
}

void main() {
  print("Fibbonacci Checker\n");
  List<int> list = new List();
  print("Enter size of list(size must be greater than 5 less than 20): ");
  int size = int.parse(stdin.readLineSync());

  if (size < 5 || size > 20) {
    print("Invalid size");

  }
 else 
{
    for (int m = 0; m < size; m++) {
      int x = m + 1;
      print("Enter number $x: ");
      list.add(int.parse(stdin.readLineSync()));
    }
    print(list);
    print(checkFib(list));
  }
}
