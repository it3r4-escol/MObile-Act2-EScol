// importing dart:io file
import 'dart:io';

void main() {
  double b1 = 42.79;
  double b2 = 45.20;
  double b3 = 39.19;
  double b4 = 38.04;

  print('Type of Payment');
  var m = stdin.readLineSync();
  if (m == 'cash') {

    print('Type of Fuel');
    var c = stdin.readLineSync();
    if (c == 'leaded') {

      print('Input Amount: ');
      var n = int.parse(stdin.readLineSync());
      var sum = n / b1;

      print('$sum Liter Of Leaded GASOLINE');
      print('Thank you');

    }
 else if (c == 'unleaded') {
      print('Input Amount: ');
      var n = int.parse(stdin.readLineSync());
      var sum = n * b2;
      print('$sum Liter Of Unleaded GASOLINE');
      print('Thank you');

    }
 else if (c == 'diesel') {

      print('Input Amount: ');
      var n = int.parse(stdin.readLineSync());
      var sum = n / b3;
      print('$sum Liter Of Diesel GASOLINE');
      print('Thank you');
    }
 else if (c == 'biodiesel') {
      print('Input Amount: ');
      var n = int.parse(stdin.readLineSync());
      var sum = n / b4;
      print('$sum Liter Of BioDiesel GASOLINE');
      print('Thank you');
    }
 	else {
      print('No Transaction');
    }
  }
 else if (m == 'liters') {
    if (m == 'liters') {
	
      print('Type of GASOLINE');
      var c = stdin.readLineSync();
      if (c == 'leaded') {

        print('Input How many Liters: ');
        var n = int.parse(stdin.readLineSync());
        var sum = n * b1;
        print('Total Cash Amount:$sum');
        print('Thank you');

      }
 else if (c == 'unleaded') {
        print('Input How many Liters: ');
        var n = int.parse(stdin.readLineSync());
        var sum = n * b2;
        print('Total Cash Amount:$sum');
        print('Thank you');

      } else if (c == 'diesel') {
        print('Input How many Liters: ');
        var n = int.parse(stdin.readLineSync());
        var sum = n * b3;
        print('Total Cash Amount:$sum');
        print('Thank you');

      } else if (c == 'biodiesel') {
        print('Input How many Liters ');
        var n = int.parse(stdin.readLineSync());
        var sum = n * b4;
        print('Total Cash Amount:$sum');
        print('Thank you');
      }
else {
        print('No Transaction');
      }
    }
  } 
else {
    print('No Transaction');
  }
}
